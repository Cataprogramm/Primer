function mostrarToast() {
  var tostada = document.getElementById("toast");
  tostada.classList.add("mostrar");
}
/*He creado está función para que cuando se pulse el botón le salga la notificación*/
/*classList me permite acceder a la lista de clases de mi elemento*/
